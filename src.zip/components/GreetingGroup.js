import React, { Component } from "react";

import Greeting from "./Greeting";

import { View } from "react-native";

export default class GreetingGroup extends Component {
  render() {
    return (
      <View>
        {/* 자식 컴포넌트에 props로 name을 전달 */}
        <Greeting name="김현수"></Greeting>
        <Greeting name="신윤수"></Greeting>
        <Greeting name="김현수"></Greeting>
        <Greeting name="김철수"></Greeting>
      </View>
    );
  }
}
